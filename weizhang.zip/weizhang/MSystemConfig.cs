using System;
namespace weizhang
{
	public class MSystemConfig
	{
		public string AirCode
		{
			get;
			set;
		}
		public string Type
		{
			get;
			set;
		}
		public string XinagShi
		{
			get;
			set;
		}
		public string BackGroud
		{
			get;
			set;
		}
		public string Hsb
		{
			get;
			set;
		}
		public string RueiHua
		{
			get;
			set;
		}
		public string Za
		{
			get;
			set;
		}
		public string XuanZhuan
		{
			get;
			set;
		}
		public string Engine
		{
			get;
			set;
		}
	}
}
