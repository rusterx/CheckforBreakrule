using System;
namespace weizhang
{
	public class MValidate
	{
		public string C
		{
			get;
			set;
		}
		public string Code
		{
			get;
			set;
		}
	}
}
