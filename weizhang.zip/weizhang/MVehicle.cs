using System;
namespace weizhang
{
	public class MVehicle
	{
		public string CardNo
		{
			get;
			set;
		}
		public string VinNo
		{
			get;
			set;
		}
		public string CheckResult
		{
			get;
			set;
		}
	}
}
