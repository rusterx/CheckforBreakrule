using System;
namespace weizhang
{
	public enum HttpRequestType
	{
		POST,
		GET
	}
}
