using System;
namespace weizhang
{
	public class MLOcation
	{
		public int X
		{
			get;
			set;
		}
		public int Y
		{
			get;
			set;
		}
	}
}
