﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using Excel;
using System.Diagnostics;
using System.Threading;
using System.ComponentModel;
using System.Net;
using System.Text;

namespace weizhang
{
    public partial class Form1 : Form
    {
        //domain config
        private string mainUrl = "";
        private string imageUrl = "";
        private string status = "";
        List<MVehicle> vehicleLs = new List<MVehicle>();
        ExcelHelper eh = new ExcelHelper();
        ValidCodeBll codeBll = new ValidCodeBll();
        public delegate void CallBackDelegate();
        string fileName;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// BackgroundWorker线程通过DoWorkEventHandler委托去委托UpdateStatus去更新UI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdateStatus(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                //必须用this.Invoke这个函数
                this.Invoke((MethodInvoker)delegate
                {
                    toolStripStatusLabel2.Text = status;
                });
                Thread.Sleep(100);
            }
        }

        /// <summary>
        /// 由于子线程会阻塞SaveFileDialog，所以利用委托，当子线完成任务是，委托他去主线程把
        /// CallBack这个函数执行
        /// </summary>
        public void CallBack()
        {

            System.Data.DataTable dt = new System.Data.DataTable();
            //dt.Columns.Add("车牌号", Type.GetType("System.String"));
            //dt.Columns.Add("车架号", Type.GetType("System.String"));
            //DataColumn dc = new DataColumn("结果", Type.GetType("System.String"));
            //dt.Columns.Add(dc);
            fileName = "";
            string currentTim = System.DateTime.Now.ToString("yyyyMMdd_HHmmss");
            int index = 0;
            foreach (MVehicle temp2 in vehicleLs)
            {
                if (index == 0)
                {
                    fileName += temp2.CardNo + "查询结果" + currentTim + ".xlsx";
                    dt.Columns.Add(temp2.CardNo, Type.GetType("System.String"));
                    dt.Columns.Add(temp2.CheckResult, Type.GetType("System.String"));
                }
                else
                {                
                    DataRow dr = dt.NewRow();
                    dr[0] = temp2.CardNo;
                    //dr["车架号"] = temp2.VinNo;
                    dr[1] = temp2.CheckResult;
                    dt.Rows.Add(dr);
                }
                index++;

            }
            //是否存在“查询结果文件夹”
            string dir = Path.Combine(Application.StartupPath, "查询结果");
            string fullpath = Path.Combine(dir, fileName);
            if (!Directory.Exists(dir))
            {
                DirectoryInfo di = new DirectoryInfo(dir);
                di.Create();
            }
            eh.DataTabletoExcel(dt, fullpath);
            MessageBox.Show("查询结束!");
        }



        /// <summary>
        /// 导入Excel提取信息，然后获取信息，并存在Excel中。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnImport_Click(object sender, EventArgs e)
        {
            string domainPath = Path.Combine(Application.StartupPath, "domain.txt");
            FileStream fs = new FileStream(@domainPath, FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            mainUrl = sr.ReadLine().TrimEnd('\n').TrimEnd('\r');
            imageUrl = sr.ReadLine().TrimEnd('\n').TrimEnd('\r');
            sr.Close();
            fs.Close();

            //委托UpdateStatus去更新主界面
            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(UpdateStatus);
            bw.RunWorkerAsync();

			
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.FileName = "";
            ofd.Filter = "Excel文档(*.xlsx,*.xls)|*.xlsx;*.xls";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                DataTable dtCar = eh.ExcelToDataTable(ofd.FileName, ExcelHelper.HDR.NO);
                for (int i = 0; i < dtCar.Rows.Count; i++)
                {
                    vehicleLs.Add(new MVehicle
                    {
                        CardNo = dtCar.Rows[i][0].ToString(),
                        VinNo = dtCar.Rows[i][1].ToString()
                    });
                }

                Thread oThread = new Thread(new ThreadStart(fetchResult));
                oThread.Start();
            }
        }

        /// <summary>
        /// 获取结果
        /// </summary>
        private void fetchResult()
        {

            codeBll.mainUrl = mainUrl;
            codeBll.imageUrl = imageUrl;
            foreach (MVehicle temp in vehicleLs)
            {
                if (!string.IsNullOrEmpty(temp.CardNo) && !string.IsNullOrEmpty(temp.VinNo))
                {
                    //访问网络是会阻塞UI线程的
                    temp.CheckResult = codeBll.GetCheckResult(temp.CardNo, temp.VinNo);
                    status = String.Format("正在获取车牌号为{0}的违章信息...", temp.CardNo);
                }
            }
            status = "查询结束";
            CallBackDelegate cbd = new CallBackDelegate(CallBack);
            this.Invoke(cbd);
        }
    }
}
